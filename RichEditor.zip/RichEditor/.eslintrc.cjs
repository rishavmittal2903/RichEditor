'use strict';

module.exports = {
  root: true,
};
