import * as React from 'react';
import { HTMLAttributes } from 'react';

/**
 * RichEditorToolbar component to provide support for inbuilt tool or custom tool 
 * @param {HTMLAttributes<HTMLDivElement>} props RichEditorToolbar component props
 * @returns  {JSX.Element} return react element
 */
export function RichEditorToolbar(props: HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className="rich-editor-toolbar" />;
}
