import * as React from 'react';
import { useEditorState } from '../editor/RichEditorContext';

/**
 * Separator component
 * @returns {JSX.Element} return react element
 */
export function Separator() {
  const editorState = useEditorState();

  if (editorState.htmlMode) {
    return null;
  }

  return <div className="rich-editor-separator" />;
}
