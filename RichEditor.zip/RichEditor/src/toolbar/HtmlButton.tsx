import * as React from 'react';
import { useEditorState } from '../editor/RichEditorContext';

/**
 * HtmlButton component
 * @param {*} param0 - HtmlButton props
 * @returns {*} return react element
 */
export function HtmlButton({ ...rest }) {
  const editorState = useEditorState();

  function onClick() {
    editorState.update({
      htmlMode: !editorState.htmlMode,
    });
  }

  return (
    <button
      className="rich-editor-btn"
      data-active={editorState.htmlMode}
      onClick={onClick}
      tabIndex={-1}
      title="HTML mode"
      type="button"
      {...rest}
    >
      &lt;/&gt;
    </button>
  );
}
