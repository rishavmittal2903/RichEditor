import type { ReactNode } from 'react';
import * as React from 'react';

export const RichEditorContext = React.createContext<EditorState | undefined>(
  undefined,
);

/**
 * Component to handle context state
 * @param {*} param0  component props
 * @returns {*} return context provider
 */
export function RichEditorProvider({ children }: { children: ReactNode }) {
  const [state, setState] = React.useState<EditorState>({
    htmlMode: false,
    update,
  });

  function update(attrs: EditorState) {
    setState((prevState) => {
      return {
        ...prevState,
        ...attrs,
        date: Date.now(),
      };
    });
  }

  return (
    <RichEditorContext.Provider value={state}>{children}</RichEditorContext.Provider>
  );
}

/**
 * custom hook to handle context
 * @returns {EditorState} return EditorState
 */
export function useEditorState(): EditorState {
  const context = React.useContext(RichEditorContext);
  if (!context) {
    throw new Error('It should wrap under parent RichEditorProvider');
  }

  return context;
}

export interface EditorState {
  update(attrs: Partial<EditorState>): void;
  $el?: HTMLElement;
  $selection?: Node;
  htmlMode: boolean;
}
