import * as React from 'react';

/**
 * HtmlEditor component to provide textarea to enter value
 * @param {*} param0 component props
 * @returns  {JSX.Element} return jsx element
 */
export function HtmlEditor({ ...rest }) {
  return <textarea {...rest} />;
}
