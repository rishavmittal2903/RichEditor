import * as React from 'react';
import { Editor, EditorProps } from './Editor';
import { RichEditorProvider } from './RichEditorContext';
import {
  Bold,
  BulletList,
  ClearFormatting,
  Italic,
  LinkAttach,
  NumberedList,
  Redo,
  StrikeThrough,
  Underline,
  Undo,
  HtmlButton,
  Separator,
  RichEditorToolbar,
} from '../toolbar';

/**
 * RichEditor component
 * @param {EditorProps} props component props
 * @returns {JSX.Element} return react element
 */
export function RichEditor(props: EditorProps) {
  return (
    <RichEditorProvider>
      <Editor {...props}>
        <RichEditorToolbar>
          <Undo />
          <Redo />
          <Separator />
          <Bold />
          <Italic />
          <Underline />
          <StrikeThrough />
          <Separator />
          <NumberedList />
          <BulletList />
          <Separator />
          <LinkAttach />
          <ClearFormatting />
          <HtmlButton />
          <Separator />
        </RichEditorToolbar>
      </Editor>
    </RichEditorProvider>
  );
}
