import type { ComponentProps, SyntheticEvent } from 'react';
import * as React from 'react';
// import { getSelectedNode } from '../utils';
import { EditableRichEditorContent, EditableRichEditorContentProps } from './EditableRichEditorContent';
import { useEditorState } from './RichEditorContext';
import { HtmlEditor } from './HtmlEditor';
import '../styles.css';

/**
 * Editor component to provide content area to format the value
 * @param {EditorProps} param0 - component props 
 * @returns  {JSX.Element} return react element
 */
export function Editor({
  children,
  containerProps,
  onSelect,
  ...rest
}: EditorProps) {
  const editorState = useEditorState();

  React.useEffect(() => {
    document.addEventListener('click', onClickOutside);
    return () => document.removeEventListener('click', onClickOutside);
  });

  /**
   * Method to trigger when user click outside
   * @param {MouseEvent} event -MouseEvent 
   * @returns 
   */
  function onClickOutside(event: MouseEvent) {
    if (event.target === editorState.$el) {
      return;
    }

    if (editorState.$el?.contains(event.target as HTMLElement)) {
      return;
    }

    editorState.update({ $selection: undefined });
  }

  /**
   * Method which will update the event on type in the text area
   * @param {SyntheticEvent<HTMLElement>} event SyntheticEvent event
   */
  function onTextSelect(event: SyntheticEvent<HTMLElement>) {
    onSelect?.(event);
    //editorState.update({ $selection: getSelectedNode() });
  }

  /**
   * Method to set the ref for dom element
   * @param {HTMLElement} $el html element
   */
  function setEditorRef($el: HTMLElement) {
    editorState.update({ $el });
  }

  if (editorState.htmlMode) {
    return (
      <div className="rich-editor" {...containerProps}>
        {children}
        <HtmlEditor {...rest} className="rich-content-editor rich-editor-html" />
      </div>
    );
  }

  return (
    <div className="rich-editor" {...containerProps}>
      {children}
      <EditableRichEditorContent
        {...rest}
        ref={setEditorRef}
        onSelect={onTextSelect}
        className="rich-content-editor"
      />
    </div>
  );
}

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface EditorProps extends EditableRichEditorContentProps {
  containerProps?: ComponentProps<'div'>;
}
