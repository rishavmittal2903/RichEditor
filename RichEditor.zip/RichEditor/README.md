# Rich Editor
Rich editor for basic editor functionality to format the text
## Description
Editor has capability to copy the format of text, image, link, ordered and unordered list with custom component flexibility. Custom button can be added in the editor with custom logic defined. It is very light weighted with size of max 10kb.

## Usage

 1. How to Install

    `npm install react-rich-editor`
    
 2. How to use it
 
    ```jsx
    import { useState } from 'react';
    import RichEditor from 'react-rich-editor';
    
    function App() {
      const [value, setValue] = useState('test value');
      
      function onChange(e) {
        setValue(e.target.value);
      }
    
      return (
        <RichEditor value={value} onChange={onChange} />
      );
    }
    ```
    
### How to customize

```tsx
import { useState } from 'react';
import { 
  Bold,
  Italic,
  Editor,
  RichEditorProvider,
  RichEditorToolbar
} from 'react-rich-editor';

export default function CustomEditor() {
  const [value, setValue] = useState('simple text');

  function onChange(e) {
    setValue(e.target.value);
  }

  return (
    <RichEditorProvider>
      <Editor value={value} onChange={onChange}>
        <RichEditorToolbar>
          <Bold />
          <Italic />
        </RichEditorToolbar>
      </Editor>
    </RichEditorProvider>
  );
}
```
### Custom Rich editor Toolbar
Editor contains a in-built feature like Bol, italic, ordered list, un-ordered list, Link attach, strike through etc. But it can be extended by creating by own as well

```tsx
import { 
  Bold, 
  Italic, 
  Editor, 
  RichEditorProvider, 
  RichEditorToolbar
} from 'react-rich-editor';

const FileUpload = <input type="file" onChange={fileHandler}/>;

export default function ExampleRichEditor({ value, onChange }) {
  return (
    <RichEditorProvider>
      <Editor value={value} onChange={onChange}>
        <RichEditorToolbar>
          <Bold />
          <Italic />
          <FileUpload />
        </RichEditorToolbar>
      </Editor>
    </RichEditorProvider>
  );
}
```

### How to customize Editor style and css

By default, it fills the whole width of the parent element, and the height
depends on a content height. It could be customized easily. The root element
of the editor has `rich-editor` css class, so you could use it in your styles.

Also, you can pass `containerProps` to customize editor appearance. Here's an
example how make the editor resizable:

```tsx
<Editor 
  containerProps={{ style: { resize: 'vertical' } }}
  value={html}
  onChange={onChange}
/>
```
All css classes are consistent, so feel free to use these names in your css:

- `rich-editor` (root container)
- `rich-content-editor` (editable area)
- `rich-editor-toolbar`
  - `rich-editor-btn`
  - `rich-editor-separator`
  - `rich-editor-dropdown` (drop down list)
